#include<stdio.h>
#include<conio.h>
//S
main()
{
 int i,j;
 clrscr();

 for(i=1;i<=7;i++)
 {
   for(j=1;j<=1;j++)
   {
     if(i==1||i==7)
     {
	 printf("******\n");
     }
     else
     {
	if(i==2||i==6)
	{
	 printf("*     *\n");
	 }
	 else
	 {

	 }
     }
    }
 }
 getch();

 }